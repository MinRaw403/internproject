// App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import LoginPage from "./pages/LoginForm";
import FogotpasswordPage1 from "./pages/fogotpasswordpage1";
import VerificationPage from "./pages/VerificationPage";
import EmailVerifiedpage from "./pages/EmailVerifiedpage";
import Passwordresetpage from "./pages/Passwordresetpage";
import SuccessfullyResetPassword from "./pages/SuccessfullyResetPassword";
import MainPage from "./pages/MainPage";

function App() {
    return (
        <Router>
            <Routes>
                {/*.........*/}
                <Route path="/" element={<LoginPage />} />
                <Route path="/main" element={<MainPage />} />
                <Route path="/forgot-password" element={<FogotpasswordPage1 />} />
                <Route path="/verify" element={<VerificationPage />} />
                <Route path="/reset-password" element={<Passwordresetpage />} />
                <Route path="/email-verified" element={<EmailVerifiedpage />} />

                <Route path="/success" element={<SuccessfullyResetPassword />} />


            </Routes>
        </Router>
    );
}

export default App;
