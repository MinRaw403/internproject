import React from 'react';
import './MainPage.css';
import suppliersImg from '../images/Suppliers.png';
import itemsCategoryImg from '../images/itemsCatedotys.png';
import itemsImg from '../images/items.png';
import departmentImg from '../images/Department.png';
import reportsImg from '../images/Reports.png';
import purchaseOrderImg from '../images/PurchaseOrder.png';
import grnImg from '../images/GRN.png';
import issueNoteImg from '../images/Issuenote.png';


const cards = [
    { title: 'Suppliers', image: suppliersImg },
    { title: 'Items Category', image: itemsCategoryImg },
    { title: 'Items', image: itemsImg },
    { title: 'Department', image: departmentImg },
    { title: 'Report', image: reportsImg },
    { title: 'Purchase Order', image: purchaseOrderImg },
    { title: 'GRN', image: grnImg },
    { title: 'Issue note', image: issueNoteImg },
];
const row1 = cards.slice(0, 3); // first 3
const row2 = cards.slice(3, 5); // next 2
const row3 = cards.slice(5);    // last 3


function MainPage() {
    return (
        <div className="main-container">
            <header className="top-bar">
                <div className="menu-icon">☰</div>
                <div className="company-name">
                    SMARTSTOCK <span>(PVT) LTD</span>
                </div>
                <div className="user-icon">👤</div>
            </header>

            <h2 className="dashboard-title">Stock Management System Dashboard</h2>

            <div className="card-row">
                {row1.map((card, index) => (
                    <div className="dashboard-card" key={index}>
                        <img src={card.image} alt={card.title} className="card-img" />
                        <p className="card-title">{card.title}</p>
                    </div>
                ))}
            </div>

            <div className="card-row">
                {row2.map((card, index) => (
                    <div className="dashboard-card" key={index}>
                        <img src={card.image} alt={card.title} className="card-img" />
                        <p className="card-title">{card.title}</p>
                    </div>
                ))}
            </div>

            <div className="card-row">
                {row3.map((card, index) => (
                    <div className="dashboard-card" key={index}>
                        <img src={card.image} alt={card.title} className="card-img" />
                        <p className="card-title">{card.title}</p>
                    </div>
                ))}
            </div>



            <footer className="footer">
                <div className="footer-section company-info">
                    <div className="black-box"></div>
                    <p>
                        Built with precision, powered by innovation. Delivering smart, scalable, and seamless stock management
                        solutions for the future of business.
                    </p>
                </div>
                <div className="footer-section quick-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li>Home</li>
                        <li>About</li>
                        <li>Features</li>
                        <li>Testimonials</li>
                    </ul>
                </div>
                <div className="footer-section newsletter">
                    <h4>Subscribe to our newsletter</h4>
                    <p>The latest news, articles, and resources, sent to your inbox weekly.</p>
                    <div className="subscribe">
                        <input type="email" placeholder="Enter your email" />
                        <button>Submit</button>
                    </div>
                </div>
            </footer>

            <div className="copyright">
                Copyright 2025 © Proxima Technologies Pvt.Ltd. All Right Reserved.
            </div>
        </div>
    );
}

export default MainPage;
